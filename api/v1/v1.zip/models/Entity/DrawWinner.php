<?php

namespace Model\Entity;


class DrawWinner extends \ShQuery
{
    public static $table_name = "draw_winner";
}
