<?php

namespace Model\Entity;


class Contact extends \ShQuery
{
    public static $table_name = "contact";
}
