<?php

namespace Model\Entity;


class Library extends \ShQuery
{
    public static $table_name = "library";
}
