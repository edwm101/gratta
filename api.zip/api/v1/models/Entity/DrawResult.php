<?php

namespace Model\Entity;


class DrawResult extends \ShQuery
{
    public static $table_name = "draw_result";
}
