<?php

namespace Model\Entity;


class User extends \ShQuery
{
    public static $table_name = "user";
}
