<?php

namespace Model\Entity;


class DrawCode extends \ShQuery
{
    public static $table_name = "draw_code";
}
