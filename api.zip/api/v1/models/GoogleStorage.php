<?php

namespace Model\GoogleStorage;


class GoogleStorage extends \ShQuery
{
    public static $table_name = "user";
}
