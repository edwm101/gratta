    <div style="min-width:100%;width:100%;font-family: Arial,sans-serif;margin-bottom:10px" >
        <table style="border-spacing:0;color:rgba(0,0,0,0.9);letter-spacing:0em;line-height:1.4;margin-top:0;margin-right:auto;margin-bottom:0;margin-left:auto;padding-left:4px;padding-right:4px;width:100%;max-width:648px;padding-bottom:0px" bgcolor="#f9f9f9">
            <tbody>
                <tr>
                    <td style="min-width:100%;width:100%;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px">
                        <div style="color:rgba(0,0,0,0.54);padding:10px 0">
                            <div style="font-size:18px;font-weight:700;margin-bottom:8px;margin-top: 5px;color: #000;">Mon<span style="
    color: #fcb414;
">Shop</span>.tn</div>
                            <div style="height:2px;border-bottom:1px solid #e5e5e5"></div>
                            <div style="font-size:14px;padding-top:8px">Bonne recherche. L'équipe de MonShop</div>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>