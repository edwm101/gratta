<div style="font-family:Arial,sans-serif;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;
    background: #f9f9f9;">
    <?php include("header.php"); ?>
    <table style="min-width:100%;width:100%">
        <tbody>
            <tr>
                <td style="min-width:100%;width:100%;padding-top:10px;padding-right:0px;padding-bottom:0px;padding-left:0px"><img src="https://ci5.googleusercontent.com/proxy/PJb94spzVqTF69ueTA3mX2IDBDDqE-upDBilm5k7HqfG6wULII9ogfSX-uuN9RtvMPLHieJDsXXbGCPfAi4Q5hQLf_ZGVcROPNr7BVpBXAHFvz9rXjPl3m5vYeN_ix0hDYah2OfJc1b4BYFG5RWufMD-fcRAtaALAee-NVhYf9JUcJJT3Mo2AmN89MZAjRLUKiwIoF7cLaIUfSFatfEJWcWZmtCuQeUqJ4p7FziBeI9DTu5MnZGYoe9kMXt3FcKPIPZwRNO1j7nAO-jcrOh-EyEA4movODAU-o_cs9wihlo=s0-d-e1-ft#https://medium.com/_/stat?event=email.opened&amp;emailId=c982011f-8d3e-4aa0-ac22-748c5746b0bb&amp;source=email-9c89674c30b9-1589251704123-digest.reader-------------------------c982011f_8d3e_4aa0_ac22_748c5746b0bb" width="1" height="1" class="CToWUd">
                    <div>
                        <table width="600" style="border-spacing:0;color:rgba(0,0,0,0.9);letter-spacing:0em;line-height:1.4;margin-top:0;margin-right:auto;margin-bottom:0;margin-left:auto;padding-left:4px;padding-right:4px;width:100%;max-width: 445px;">
                            <tbody>
                                <tr style="margin: 20px 0;display:block;" align="center">
                                    <td style="box-shadow: 0 1px 3px #d0d0d0;background: white;" width="238" valign="middle">
                                        <div style="width: 100%;display:inline-block;float:left;height:100%;padding: 10px 0;background: #f5f5f5;">Code</div>
                                        <div style="width: 100%;display:inline-block;float:left;letter-spacing: 5px;height:100%;padding:10px 0;color: #000;font-size: 26px;font-weight: 500;"><?= @$params["code"] ?></div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
    <?php include("footer.php"); ?>
</div>